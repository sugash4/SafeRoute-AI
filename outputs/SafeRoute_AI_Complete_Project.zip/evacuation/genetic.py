from __future__ import annotations

from dataclasses import dataclass
from random import Random

from .algorithms import astar
from .models import CampusGraph


@dataclass(frozen=True)
class GeneticResult:
    locations: tuple[str, ...]
    average_cost: float
    history: list[float]
    generations: int


def optimize_resource_locations(
    graph: CampusGraph,
    candidates: list[str],
    demand_nodes: list[str],
    location_count: int = 2,
    population_size: int = 24,
    generations: int = 35,
    mutation_rate: float = 0.18,
    seed: int = 42,
    hazard_weight: float = 4.0,
    congestion_weight: float = 2.0,
) -> GeneticResult:
    """Place emergency resources with selection, crossover, mutation, and elitism."""
    unique_candidates = sorted(set(candidates))
    if not demand_nodes:
        raise ValueError("Demand nodes are required")
    if location_count < 1 or location_count > len(unique_candidates):
        raise ValueError("Location count must fit within the candidate set")
    if population_size < 4 or generations < 1:
        raise ValueError("Population must be at least 4 and generations positive")
    rng = Random(seed)

    def chromosome() -> tuple[str, ...]:
        return tuple(sorted(rng.sample(unique_candidates, location_count)))

    cost_cache: dict[tuple[str, str], float] = {}

    def fitness(individual: tuple[str, ...]) -> float:
        total = 0.0
        for demand in demand_nodes:
            costs: list[float] = []
            for location in individual:
                key = (demand, location)
                if key not in cost_cache:
                    cost_cache[key] = astar(
                        graph, demand, location, hazard_weight, congestion_weight
                    ).weighted_cost
                costs.append(cost_cache[key])
            total += min(costs)
        return total / len(demand_nodes)

    def tournament(population: list[tuple[str, ...]]) -> tuple[str, ...]:
        sample = rng.sample(population, min(3, len(population)))
        return min(sample, key=fitness)

    def crossover(left: tuple[str, ...], right: tuple[str, ...]) -> tuple[str, ...]:
        pool = sorted(set(left + right))
        chosen = rng.sample(pool, min(location_count, len(pool)))
        remaining = [node for node in unique_candidates if node not in chosen]
        if len(chosen) < location_count:
            chosen.extend(rng.sample(remaining, location_count - len(chosen)))
        return tuple(sorted(chosen))

    def mutate(individual: tuple[str, ...]) -> tuple[str, ...]:
        if rng.random() >= mutation_rate:
            return individual
        genes = list(individual)
        replacement_pool = [node for node in unique_candidates if node not in genes]
        if replacement_pool:
            genes[rng.randrange(len(genes))] = rng.choice(replacement_pool)
        return tuple(sorted(genes))

    population: list[tuple[str, ...]] = []
    attempts = 0
    while len(population) < population_size and attempts < population_size * 20:
        candidate = chromosome()
        if candidate not in population:
            population.append(candidate)
        attempts += 1
    while len(population) < population_size:
        population.append(chromosome())
    history: list[float] = []

    for _ in range(generations):
        ranked = sorted(population, key=fitness)
        history.append(fitness(ranked[0]))
        next_population = ranked[:2]
        while len(next_population) < population_size:
            child = mutate(crossover(tournament(population), tournament(population)))
            next_population.append(child)
        population = next_population

    best = min(population, key=fitness)
    history.append(fitness(best))
    return GeneticResult(best, fitness(best), history, generations)
