from __future__ import annotations

import pandas as pd
import streamlit as st

from evacuation.algorithms import ALGORITHMS
from evacuation.planning import simulate_unexpected_blockage
from evacuation.risk import combine_sensor_evidence
from evacuation.scenarios import EXITS, SCENARIOS, apply_scenario, base_campus
from evacuation.visualization import campus_figure


st.set_page_config(page_title="SafeRoute AI", page_icon="🧭", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&family=Space+Grotesk:wght@500;600&display=swap');
:root { --ink:#071526; --panel:#0b1728; --line:#29415f; --cyan:#8ae8ff; --mint:#38d9a9; --amber:#ffb703; }
.stApp { background: radial-gradient(circle at 80% 0%, #142e47 0, #071526 34rem); color:#eaf2f8; }
h1,h2,h3 { font-family:'Space Grotesk',sans-serif !important; letter-spacing:-0.035em; }
[data-testid="stSidebar"] { background:#091321; border-right:1px solid #263b54; }
[data-testid="stMetric"] { background:#0d1d31; border:1px solid #29415f; padding:1rem; border-radius:4px; }
[data-testid="stMetricValue"] { font-family:'IBM Plex Mono',monospace; color:#8ae8ff; }
.eyebrow { font:600 .75rem 'IBM Plex Mono'; color:#8ae8ff; letter-spacing:.16em; text-transform:uppercase; }
.hero { border-left:4px solid #38d9a9; padding:.15rem 0 .15rem 1.2rem; margin:.4rem 0 1.6rem; }
.hero p { color:#9db0c3; max-width:56rem; }
.status { font:600 .8rem 'IBM Plex Mono'; color:#38d9a9; }
.route { font:500 .92rem 'IBM Plex Mono'; color:#d8e3ed; background:#0d1d31; border:1px solid #29415f; padding:.85rem 1rem; border-radius:4px; }
.legend { font:.78rem 'IBM Plex Mono'; color:#91a4b8; }
.stButton button { border-radius:3px; border:1px solid #38d9a9; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="eyebrow">Intelligent evacuation laboratory · CO2 / CO3 / CO5</div>', unsafe_allow_html=True)
st.markdown('<div class="hero"><h1>SafeRoute AI</h1><p>Compare classical search strategies on a campus whose risk changes while people move.</p></div>', unsafe_allow_html=True)

with st.sidebar:
    st.header("Mission controls")
    scenario = st.selectbox("Emergency scenario", SCENARIOS)
    graph = base_campus()
    apply_scenario(graph, scenario)
    starts = [node for node in graph.positions if node not in EXITS]
    start = st.selectbox("Starting location", starts, index=starts.index("Library"))
    goal = st.selectbox("Safe exit", EXITS, index=1)
    algorithm_name = st.selectbox("Search strategy", list(ALGORITHMS), index=3)
    st.divider()
    st.caption("Cost priorities")
    hazard_weight = st.slider("Hazard penalty", 0.0, 10.0, 5.0, 0.5)
    congestion_weight = st.slider("Congestion penalty", 0.0, 6.0, 2.0, 0.5)

    with st.expander("Bayesian sensor update"):
        sensor_node = st.selectbox("Sensor location", list(graph.positions), index=list(graph.positions).index("Central Atrium"))
        prior = st.slider("Prior hazard probability", 0.01, 0.99, 0.10, 0.01)
        smoke = st.checkbox("Smoke alarm is positive")
        heat = st.checkbox("Heat alarm is positive")
        posterior = combine_sensor_evidence(prior, smoke, heat)
        if st.button("Apply sensor evidence", use_container_width=True):
            st.session_state["sensor_override"] = (sensor_node, posterior)
        st.metric("Posterior risk", f"{posterior:.1%}")

sensor_override = st.session_state.get("sensor_override")
if sensor_override:
    graph.hazards[sensor_override[0]] = sensor_override[1]

algorithm = ALGORITHMS[algorithm_name]
result = algorithm(graph, start, goal, hazard_weight, congestion_weight)

tab_map, tab_compare, tab_replan, tab_learn = st.tabs(["Live map", "Compare algorithms", "Replanning drill", "How the AI decides"])

with tab_map:
    if result.reached:
        st.markdown('<div class="status">● ROUTE FOUND</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="route">{" → ".join(result.path)}</div>', unsafe_allow_html=True)
    else:
        st.error("No safe route exists with the current blocked corridors.")

    max_step = max(1, result.nodes_expanded)
    exploration_step = st.slider("Search replay · nodes expanded", 1, max_step, max_step)
    st.plotly_chart(campus_figure(graph, result, exploration_step), use_container_width=True, config={"displayModeBar": False})
    st.markdown('<div class="legend">CYAN · explored &nbsp;&nbsp; MINT · selected route &nbsp;&nbsp; AMBER · elevated risk &nbsp;&nbsp; RED · severe risk / blocked</div>', unsafe_allow_html=True)

    columns = st.columns(4)
    columns[0].metric("Weighted cost", f"{result.weighted_cost:.2f}" if result.reached else "∞")
    columns[1].metric("Route distance", f"{result.distance:.1f}" if result.reached else "—")
    columns[2].metric("Nodes expanded", result.nodes_expanded)
    columns[3].metric("Runtime", f"{result.runtime_ms:.3f} ms")

with tab_compare:
    results = [fn(graph, start, goal, hazard_weight, congestion_weight) for fn in ALGORITHMS.values()]
    rows = [{
        "Algorithm": item.algorithm,
        "Reached": "Yes" if item.reached else "No",
        "Weighted cost": round(item.weighted_cost, 2) if item.reached else None,
        "Distance": round(item.distance, 2) if item.reached else None,
        "Risk exposure": round(item.risk_exposure, 2) if item.reached else None,
        "Congestion exposure": round(item.congestion_exposure, 2) if item.reached else None,
        "Nodes expanded": item.nodes_expanded,
        "Runtime (ms)": round(item.runtime_ms, 4),
        "Route": " → ".join(item.path) if item.reached else "No route",
    } for item in results]
    frame = pd.DataFrame(rows)
    st.dataframe(frame, hide_index=True, use_container_width=True)
    chart_data = frame.set_index("Algorithm")[["Weighted cost", "Nodes expanded"]]
    st.bar_chart(chart_data, color=["#38d9a9", "#8ae8ff"])
    best = min((item for item in results if item.reached), key=lambda item: item.weighted_cost, default=None)
    if best:
        st.info(f"Lowest risk-aware cost: **{best.algorithm.replace('*', ' star')}** at **{best.weighted_cost:.2f}**.")

with tab_replan:
    drill = simulate_unexpected_blockage(graph, start, goal, hazard_weight, congestion_weight)
    if drill.newly_blocked and drill.revised_plan:
        blocked_from, blocked_to = drill.newly_blocked
        st.markdown('<div class="eyebrow">Unexpected environment change</div>', unsafe_allow_html=True)
        st.subheader(f"Corridor closes after the agent reaches {drill.current_location}")
        first, second = st.columns(2)
        first.markdown("**Original plan**")
        first.code(" → ".join(drill.initial_plan.path), language=None)
        second.markdown("**New observation**")
        second.error(f"{blocked_from} ↔ {blocked_to} is now blocked")
        if drill.revised_plan.reached:
            st.success("The agent discarded the invalid remainder and searched again from its current state.")
            st.markdown(f'<div class="route">{" → ".join(drill.revised_plan.path)}</div>', unsafe_allow_html=True)
        else:
            st.error("No alternative path remains. The correct plan is to stop and request assistance.")
        st.plotly_chart(campus_figure(drill.revised_graph, drill.revised_plan), use_container_width=True, config={"displayModeBar": False})
    else:
        st.warning("Choose a start and exit with at least two route segments to run this drill.")

with tab_learn:
    st.subheader("Search equations")
    st.latex(r"C(u,v)=d(u,v)\,[1+w_h\,r(u,v)+w_c\,q(u,v)]")
    st.write("Distance is multiplied by hazard probability and congestion. The sidebar weights express how strongly the planner avoids each risk.")
    st.latex(r"A^*: \quad f(n)=g(n)+h(n)")
    st.write("The accumulated cost g(n) remembers what the route has already paid; the heuristic h(n) estimates straight-line distance to the exit.")
    st.latex(r"P(H\mid E)=\frac{P(E\mid H)P(H)}{P(E\mid H)P(H)+P(E\mid \neg H)P(\neg H)}")
    st.write("Bayes' rule converts uncertain smoke and heat evidence into a hazard probability used by the planner.")
    st.subheader("Observe, update, replan")
    st.write("The replanning drill moves the agent one step, introduces an unexpected blocked corridor, updates the environment state, and runs A* again from the current location—not from the original start.")
    st.subheader("Expansion order")
    st.code(" → ".join(result.expanded_order), language=None)
